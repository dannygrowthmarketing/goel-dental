<?php
/* Goel Dental theme. Daniel Deepak, Nov 2026. */
if (!defined('ABSPATH')) exit;
define('GD_TEL', '+919310207552');
define('GD_PHONE', '+91 93102 07552');
define('GD_VER', '1.2.1');

/* Show "to confirm" badges and the tracking inspector only to logged-in editors, or everywhere on staging. */
function gd_show_flags() { return current_user_can('edit_pages') || get_option('gd_staging', '0') === '1'; }

add_action('after_setup_theme', function () {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('html5', ['search-form','gallery','caption','style','script']);
  add_theme_support('responsive-embeds');
});

add_action('wp_enqueue_scripts', function () {
  wp_enqueue_style('gd-fonts', 'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600&display=swap', [], null);
  wp_enqueue_style('gd-site', get_template_directory_uri() . '/assets/css/site.css', [], GD_VER);
  wp_enqueue_script('gd-site', get_template_directory_uri() . '/assets/js/gd.js', [], GD_VER, true);
  wp_add_inline_script('gd-site', 'window.GD_CFG=' . wp_json_encode(['ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('gd_lead')]) . ';', 'before');
  /* keep the front end light: no block-library CSS on a classic theme, no emoji script */
  wp_dequeue_style('wp-block-library'); wp_dequeue_style('global-styles'); wp_dequeue_style('classic-theme-styles');
}, 20);
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'rsd_link'); remove_action('wp_head', 'wlwmanifest_link'); remove_action('wp_head', 'wp_generator');

/* GTM: paste the container ID in Settings > General (field added below). All vendor tags (GA4, Ads, Meta) live inside GTM. */
add_action('wp_head', function () {
  $id = trim(get_option('gd_gtm_id', ''));
  if ($id && preg_match('/^GTM-[A-Z0-9]+$/', $id)) {
    echo "<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','" . esc_js($id) . "');</script>\n";
  }
  if (get_option('gd_staging', '0') === '1') echo '<meta name="robots" content="noindex,nofollow">' . "\n";
}, 1);
add_action('admin_init', function () {
  register_setting('general', 'gd_gtm_id', ['sanitize_callback' => 'sanitize_text_field']);
  add_settings_field('gd_gtm_id', 'GTM container ID', function () {
    echo '<input name="gd_gtm_id" value="' . esc_attr(get_option('gd_gtm_id', '')) . '" placeholder="GTM-XXXXXXX" class="regular-text">';
  }, 'general');
});

if (!function_exists('gdr_lead_save')) {
/* Leads: every booking request is stored with its source, so it can be matched to visits and revenue. */
add_action('init', function () {
  register_post_type('gd_lead', [
    'label' => 'Leads', 'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-groups',
    'supports' => ['title'], 'capability_type' => 'post', 'map_meta_cap' => true,
  ]);
});
function gd_lead_save() {
  if (!wp_verify_nonce($_POST['_gd'] ?? '', 'gd_lead')) wp_send_json_error('bad nonce', 403);
  $name  = sanitize_text_field($_POST['name'] ?? '');
  $phone = preg_replace('/\D/', '', $_POST['phone'] ?? '');
  $phone = preg_replace('/^(91|0)(?=\d{10}$)/', '', $phone);
  if (!$name || !preg_match('/^[6-9]\d{9}$/', $phone) || empty($_POST['consent'])) wp_send_json_error('invalid', 400);
  $lid = sanitize_text_field($_POST['lead_id'] ?? '');
  $id = wp_insert_post(['post_type' => 'gd_lead', 'post_status' => 'private', 'post_title' => $lid . ' · ' . $name]);
  $keys = ['treatment','time','page','ref_code','ft_channel','ft_campaign','ft_landing','lt_channel','lt_source','lt_medium','lt_campaign','lt_term','gclid','fbclid'];
  update_post_meta($id, 'name', $name); update_post_meta($id, 'phone', $phone); update_post_meta($id, 'lead_id', $lid);
  update_post_meta($id, 'status', 'new');
  foreach ($keys as $k) update_post_meta($id, $k, sanitize_text_field($_POST[$k] ?? ''));
  $to = get_option('gd_lead_email', get_option('admin_email'));
  wp_mail($to, 'New appointment request ' . $lid, "Name: $name\nMobile: +91 $phone\nFor: " . sanitize_text_field($_POST['treatment'] ?? '') . "\nTime: " . sanitize_text_field($_POST['time'] ?? '') . "\nSource: " . sanitize_text_field($_POST['lt_channel'] ?? '') . ' / ' . sanitize_text_field($_POST['lt_campaign'] ?? ''));
  wp_send_json_success(['id' => $id]);
}
add_action('wp_ajax_gd_lead', 'gd_lead_save');
add_action('wp_ajax_nopriv_gd_lead', 'gd_lead_save');

/* Lead list columns: status, treatment, source */
add_filter('manage_gd_lead_posts_columns', function ($c) { return ['cb' => $c['cb'], 'title' => 'Lead', 'phone' => 'Mobile', 'treatment' => 'Treatment', 'source' => 'Source', 'status' => 'Status', 'date' => 'Received']; });
add_action('manage_gd_lead_posts_custom_column', function ($col, $id) {
  if ($col === 'phone') echo esc_html('+91 ' . get_post_meta($id, 'phone', true));
  if ($col === 'treatment') echo esc_html(get_post_meta($id, 'treatment', true));
  if ($col === 'source') echo esc_html(trim(get_post_meta($id, 'lt_channel', true) . ' ' . get_post_meta($id, 'lt_campaign', true)));
  if ($col === 'status') echo esc_html(get_post_meta($id, 'status', true));
}, 10, 2);
}


/* Structured data: Dentist on the homepage; MedicalProcedure + FAQPage on treatment pages (FAQ read from <details> in the content). */
add_action('wp_head', function () {
  if (is_front_page()) {
    echo '<script type="application/ld+json">' . file_get_contents(get_template_directory() . '/assets/schema-dentist.json') . "</script>\n";
    echo '<script type="application/ld+json">' . file_get_contents(get_template_directory() . '/assets/faq-home.json') . "</script>\n";
    return;
  }
  if (!is_page()) return;
  $post = get_post(); $c = get_post_meta($post->ID, 'gd_content', true) ?: $post->post_content;
  $st = get_post_meta($post->ID, 'gd_schema', true); $out = [];
  if (in_array($st, ['procedure', 'fees'], true)) $out[] = ['@context' => 'https://schema.org', '@type' => 'MedicalWebPage', 'name' => get_the_title(), 'url' => get_permalink(),
    'about' => ['@type' => 'MedicalProcedure', 'name' => preg_replace('/ in Malviya Nagar$/', '', get_the_title())],
    'publisher' => ['@type' => 'Dentist', 'name' => 'Goel Dental', 'url' => home_url('/')]];
  if (preg_match_all('#<details><summary>(.*?)</summary>(.*?)</details>#s', $c, $m, PREG_SET_ORDER)) {
    $faq = ['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => []];
    foreach ($m as $q) $faq['mainEntity'][] = ['@type' => 'Question', 'name' => wp_strip_all_tags($q[1]), 'acceptedAnswer' => ['@type' => 'Answer', 'text' => wp_strip_all_tags($q[2])]];
    $out[] = $faq;
  }
  foreach ($out as $o) echo '<script type="application/ld+json">' . wp_json_encode($o, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
}, 5);

/* Titles and descriptions when no SEO plugin is active (Yoast takes over on the live site). */
add_filter('pre_get_document_title', function ($t) {
  if (defined('WPSEO_VERSION')) return $t;
  if (is_front_page()) return 'Goel Dental | Dentist in Malviya Nagar, South Delhi';
  if (is_page()) return get_post_meta(get_the_ID(), '_yoast_wpseo_title', true) ?: get_the_title() . ' | Goel Dental';
  return $t;
});
add_action('wp_head', function () {
  if (defined('WPSEO_VERSION')) return;
  if (is_page() && !is_front_page() && get_post_meta(get_the_ID(), '_yoast_wpseo_metadesc', true)) return;
  $d = is_front_page() ? 'Dentist on Main Shivalik Road, Malviya Nagar: root canals, implants, braces, aligners, kids and emergencies. 4.8★ from 708 Google reviews. Fees published.' : (is_page() ? wp_trim_words(wp_strip_all_tags(get_post()->post_content), 28, '') : '');
  if ($d) echo '<meta name="description" content="' . esc_attr($d) . '">' . "\n";
}, 2);

/* [gd_img name="micro-rct" alt="..."] for theme photos inside page content */
add_shortcode('gd_img', function ($a) {
  $a = shortcode_atts(['name' => '', 'alt' => '', 'cap' => ''], $a);
  $src = get_template_directory_uri() . '/assets/img/' . sanitize_file_name($a['name']) . '.webp';
  return '<figure class="photo-fig"><img src="' . esc_url($src) . '" alt="' . esc_attr($a['alt']) . '" loading="lazy" decoding="async">' . ($a['cap'] ? '<figcaption class="cap">' . esc_html($a['cap']) . '</figcaption>' : '') . '</figure>';
});

/* Favicon from the clinic mark, unless a Site Icon is set in the Customizer. */
add_action('wp_head', function () {
  if (has_site_icon()) return;
  echo '<link rel="icon" href="' . esc_url(get_template_directory_uri() . '/assets/img/gd-mark.webp') . '" type="image/webp">' . "\n";
}, 3);

/* ---------- SEO structure helpers (v1.1) ---------- */
function gd_url($slug) { return home_url('/' . $slug . '.html'); }
function gd_page($slug) { $p = get_page_by_path($slug); return ($p && $p->post_status === 'publish') ? $p : null; }

/* Treatment groups used by the hub page, the related-links block and the homepage tiles. */
function gd_groups() {
  return [
    'Tooth pain & root canals' => ['root-canal-treatment', 'single-sitting-root-canal-treatment', 'microscopic-root-canal-treatment', 'dental-emergency'],
    'Missing teeth' => ['dental-implants', 'full-mouth-dental-implants', 'dental-bridge-tooth-crown'],
    'Extractions' => ['wisdom-teeth-extraction', 'non-surgical-tooth-extraction'],
    'Gums & cleaning' => ['scaling-and-polishing', 'ems-gbt-teeth-cleaning', 'gum-disease-treatment'],
    'Straighter teeth' => ['orthodontics', 'invisible-braces'],
    'Fillings, children & fees' => ['tooth-colored-filling', 'kids-dentistry', 'cost-of-dental-procedures'],
  ];
}
function gd_card($slug) {
  $p = gd_page($slug); if (!$p) return;
  $fee = get_post_meta($p->ID, 'gd_fee', true); $card = get_post_meta($p->ID, 'gd_card', true);
  echo '<a class="tcard" href="' . esc_url(get_permalink($p)) . '"><b>' . esc_html(get_post_meta($p->ID, 'gd_short', true) ?: $p->post_title) . '</b>'
     . ($card ? '<span>' . esc_html($card) . '</span>' : '') . ($fee ? '<em>' . esc_html($fee) . '</em>' : '') . '<i aria-hidden="true">→</i></a>';
}
function gd_related() {
  $id = get_the_ID(); $slugs = array_filter(array_map('trim', explode(',', get_post_meta($id, 'gd_related', true))));
  if (!$slugs) foreach (gd_groups() as $g) if (in_array(get_post_field('post_name', $id), $g, true)) $slugs = array_diff($g, [get_post_field('post_name', $id)]);
  if (!$slugs) return;
  echo '<section class="section alt" aria-labelledby="rel-h"><div class="wrap"><div class="head"><div><p class="eyebrow">Related</p><h2 id="rel-h">Also at Goel Dental</h2></div><a class="btn ghost sm" href="' . esc_url(gd_url('dental-treatments')) . '">All treatments</a></div><div class="grid g3">';
  foreach (array_slice(array_values($slugs), 0, 3) as $s) gd_card($s);
  echo '</div></div></section>';
}

/* Breadcrumbs (visible + BreadcrumbList schema). Parent is set per page in gd_parent (slug), so URLs stay flat like the live site. */
function gd_crumbs() {
  $c = [['Home', home_url('/')]]; $id = get_the_ID(); $par = get_post_meta($id, 'gd_parent', true);
  if ($par && ($pp = gd_page($par))) $c[] = [get_post_meta($pp->ID, 'gd_short', true) ?: $pp->post_title, get_permalink($pp)];
  $c[] = [get_post_meta($id, 'gd_short', true) ?: get_the_title($id), get_permalink($id)];
  return $c;
}
function gd_breadcrumbs() {
  $c = gd_crumbs(); $out = [];
  foreach ($c as $i => $x) $out[] = $i < count($c) - 1 ? '<a href="' . esc_url($x[1]) . '">' . esc_html($x[0]) . '</a>' : '<span aria-current="page">' . esc_html($x[0]) . '</span>';
  echo '<nav class="crumbs" aria-label="Breadcrumb">' . implode(' / ', $out) . '</nav>';
}
add_action('wp_head', function () {
  if (!is_page() || is_front_page()) return;
  $items = []; foreach (gd_crumbs() as $i => $x) $items[] = ['@type' => 'ListItem', 'position' => $i + 1, 'name' => $x[0], 'item' => $x[1]];
  echo '<script type="application/ld+json">' . wp_json_encode(['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $items], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
  $type = get_post_meta(get_the_ID(), 'gd_schema', true);
  if ($type === 'branch') {
    $b = json_decode(get_post_meta(get_the_ID(), 'gd_branch', true), true);
    if ($b) echo '<script type="application/ld+json">' . wp_json_encode(array_merge(['@context' => 'https://schema.org', '@type' => 'Dentist', 'parentOrganization' => ['@type' => 'Dentist', 'name' => 'Goel Dental', 'url' => home_url('/')]], $b), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
  }
  if ($type === 'team') {
    $people = json_decode(get_post_meta(get_the_ID(), 'gd_people', true), true) ?: [];
    foreach ($people as $p) echo '<script type="application/ld+json">' . wp_json_encode(array_merge(['@context' => 'https://schema.org', '@type' => 'Person', 'worksFor' => ['@type' => 'Dentist', 'name' => 'Goel Dental']], $p), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
  }
}, 6);

/* SEO title + description from page meta when Yoast is absent. On the live site the same values are stored in Yoast's own fields. */
add_filter('pre_get_document_title', function ($t) {
  if (defined('WPSEO_VERSION') || !is_page() || is_front_page()) return $t;
  return get_post_meta(get_the_ID(), '_yoast_wpseo_title', true) ?: $t;
}, 20);
add_action('wp_head', function () {
  if (defined('WPSEO_VERSION') || !is_page() || is_front_page()) return;
  $d = get_post_meta(get_the_ID(), '_yoast_wpseo_metadesc', true);
  if ($d) echo '<meta name="description" content="' . esc_attr($d) . '">' . "\n";
  echo '<link rel="canonical" href="' . esc_url(get_permalink()) . '">' . "\n";
}, 1);
/* our description wins over the generic word-trim fallback */
add_action('wp', function () { if (is_page() && !is_front_page() && get_post_meta(get_the_ID(), '_yoast_wpseo_metadesc', true)) remove_all_actions('gd_fallback_desc'); });

/* Lite YouTube: thumbnail until tapped, so videos cost nothing until played. */
add_shortcode('gd_video', function ($a) {
  $a = shortcode_atts(['id' => '', 'title' => 'Patient video', 'cap' => ''], $a); $id = preg_replace('/[^A-Za-z0-9_-]/', '', $a['id']);
  return '<figure class="lyt-fig"><button type="button" class="lyt" data-yt="' . esc_attr($id) . '" data-t="' . esc_attr($a['title']) . '" aria-label="Play video: ' . esc_attr($a['title']) . '" style="background-image:url(https://i.ytimg.com/vi/' . esc_attr($id) . '/hqdefault.jpg)"><span aria-hidden="true">▶</span></button>' . ($a['cap'] ? '<figcaption class="cap">' . esc_html($a['cap']) . '</figcaption>' : '') . '</figure>';
});
add_shortcode('gd_cards', function ($a) { $a = shortcode_atts(['slugs' => ''], $a); ob_start(); echo '<div class="grid g2 cards-in">'; foreach (explode(',', $a['slugs']) as $s) gd_card(trim($s)); echo '</div>'; return ob_get_clean(); });
add_shortcode('gd_book_form', function () { ob_start(); get_template_part('parts/book-form'); return ob_get_clean(); });
add_shortcode('gd_phone', fn() => '<a href="tel:' . esc_attr(GD_TEL) . '" data-cta="inline">' . esc_html(GD_PHONE) . '</a>');
add_shortcode('gd_wa', fn($a) => '<a href="#" data-wa data-cta="inline" data-t="' . esc_attr(shortcode_atts(['t' => ''], $a)['t']) . '">WhatsApp the clinic</a>');
add_shortcode('gd_confirm', fn($a, $c = '') => '<span class="pending">' . esc_html($c ?: 'Clinic to confirm') . '</span>');

/* preload hero: fetch the homepage photo first */
add_action('wp_head', function () { if (is_front_page()) echo '<link rel="preload" as="image" href="' . esc_url(get_template_directory_uri() . '/assets/img/clinic-front.webp') . '" fetchpriority="high">' . "\n"; }, 0);
