<?php get_header(); ?>
<main id="main">
<section class="hero" id="top" aria-labelledby="h1"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/clinic-front.webp" alt="Reception and treatment area at Goel Dental, Malviya Nagar" decoding="async">
<div class="wrap">
<p class="eyebrow">Dental clinic · Main Shivalik Road, Malviya Nagar</p>
<h1 id="h1">Dentist in Malviya Nagar. Six specialists, one clinic.</h1>
<p class="lead">Root canals under a microscope, implants, braces and Invisalign, gum and children's care. The right specialist plans your treatment, and the fee is in writing before anything starts.</p>
<div class="btns"><a class="btn accent" href="#book" data-book data-cta="hero">Book appointment</a><a class="btn ghost" href="tel:+919310207552" data-cta="hero"><svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3h3l2 5-2.5 1.5a11 11 0 0 0 7 7L16 14l5 2v3a2 2 0 0 1-2 2A17 17 0 0 1 3 5a2 2 0 0 1 2-2z"/></svg> +91 93102 07552</a><a class="btn wa" href="#" data-wa data-cta="hero"><svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.3-.4.8-1.4a.5.5 0 0 0 0-.5l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6a2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.3-.2-.5-.3z"/></svg> WhatsApp</a></div>
<div class="stats"><div><b>4.8★</b><span>717 Google reviews</span></div><div><b>2011</b><span>On Main Shivalik Road</span></div><div><b>6</b><span>Dentists &amp; specialists</span></div><div><b>₹0</b><span>Implant consultation</span></div></div>
</div></section>

<section class="section alt" aria-labelledby="router-h" data-router><div class="wrap">
<div class="head"><div><p class="eyebrow">Start here</p><h2 id="router-h">What brings you in?</h2><p class="lead" style="margin:12px 0 0">Pick the closest match. You'll see how soon to come, who you'll see, and the next step.</p></div></div>
<div class="chips" role="group" aria-label="Choose a symptom"><button class="chip" type="button" aria-pressed="false" data-r="pain">Tooth pain</button><button class="chip" type="button" aria-pressed="false" data-r="broken">Broken or chipped tooth</button><button class="chip" type="button" aria-pressed="false" data-r="gums">Bleeding gums</button><button class="chip" type="button" aria-pressed="false" data-r="wisdom">Wisdom tooth pain</button><button class="chip" type="button" aria-pressed="false" data-r="missing">Missing tooth</button><button class="chip" type="button" aria-pressed="false" data-r="crooked">Crooked or gapped teeth</button><button class="chip" type="button" aria-pressed="false" data-r="stained">Stained or yellow teeth</button><button class="chip" type="button" aria-pressed="false" data-r="child">My child</button></div>
<div class="router-out" aria-live="polite" hidden></div>
</div></section>

<section class="section" id="treatments" aria-labelledby="tx-h"><div class="wrap">
<div class="head"><div><p class="eyebrow">Treatments</p><h2 id="tx-h">Everyday care and planned treatment.</h2></div><span class="btns" style="margin:0"><a class="btn ghost sm" href="<?php echo esc_url(gd_url('dental-treatments')); ?>">All treatments</a><a class="btn ghost sm" href="https://delhidentalsmiles.com/" rel="noopener">Cosmetic &amp; smile makeovers →</a></span></div>
<div class="mosaic">
<a class="t2" href="<?php echo esc_url(gd_url('root-canal-treatment')); ?>"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/micro-rct.webp" alt="Dental operating microscope used for root canal treatment" loading="lazy" decoding="async"><span><b>Root canal treatment</b><i>From ₹4,500 · single-sitting possible</i></span></a>
<a class="w2" href="<?php echo esc_url(gd_url('dental-implants')); ?>"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/implant-caption.webp" alt="Dental implant model showing the implant, abutment and crown" loading="lazy" decoding="async"><span><b>Dental implants</b><i>Free consultation · from ₹17,000</i></span></a>
<a href="<?php echo esc_url(gd_url('dental-emergency')); ?>"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/rct-model.webp" alt="Model of a tooth showing the root canals" loading="lazy" decoding="async"><span><b>Toothache &amp; emergencies</b><i>Call first</i></span></a>
<a href="<?php echo esc_url(gd_url('invisible-braces')); ?>"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/aligner.webp" alt="Invisalign clear aligner in its case at Goel Dental" loading="lazy" decoding="async"><span><b>Invisalign &amp; braces</b><i>Two orthodontists</i></span></a>
<a href="<?php echo esc_url(gd_url('scaling-and-polishing')); ?>"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/cleaning.webp" alt="Scaling and polishing" loading="lazy" decoding="async"><span><b>Cleaning &amp; gums</b><i>EMS GBT cleaning · from ₹2,500</i></span></a>
<a class="t2" href="<?php echo esc_url(gd_url('kids-dentistry')); ?>"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/kids.webp" alt="Child smiling during a dental check-up" loading="lazy" decoding="async"><span><b>Children's dentistry</b><i>Separate kids' room</i></span></a>
<a href="<?php echo esc_url(gd_url('wisdom-teeth-extraction')); ?>"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/opg.webp" alt="OPG full-mouth X-ray machine in the clinic imaging corner" loading="lazy" decoding="async"><span><b>Wisdom teeth &amp; extractions</b><i>OPG on site</i></span></a>
<a class="w2" href="https://delhidentalsmiles.com/" rel="noopener"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/zoom.webp" alt="Philips Zoom whitening lamp with before and after shade comparison" loading="lazy" decoding="async"><span><b>Whitening, veneers, smile design</b><i>On the Delhi Dental Smiles site</i></span></a>
</div></div></section>

<section class="section alt" id="emergency" aria-labelledby="em-h"><div class="wrap split">
<div class="urgent"><p class="eyebrow">Dental emergency</p><h2 id="em-h" style="font-size:clamp(28px,3vw,40px)">In pain now? Call before you come.</h2>
<ul class="ticks"><li>Severe toothache or pain that wakes you</li><li>Swelling of the gum or face</li><li>Broken, cracked or knocked-out tooth</li><li>Bleeding that won't stop after an extraction</li></ul>
<p class="small">Swelling spreading to the eye or neck, fever, or trouble breathing or swallowing: go to a hospital emergency department now.</p>
<div class="btns"><a class="btn urgent" href="tel:+919310207552" data-cta="emergency"><svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3h3l2 5-2.5 1.5a11 11 0 0 0 7 7L16 14l5 2v3a2 2 0 0 1-2 2A17 17 0 0 1 3 5a2 2 0 0 1 2-2z"/></svg> Call +91 93102 07552</a><a class="btn wa" href="#" data-wa data-cta="emergency" data-t="Emergency"><svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.3-.4.8-1.4a.5.5 0 0 0 0-.5l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6a2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.3-.2-.5-.3z"/></svg> WhatsApp a photo</a></div></div>
<div><h3>First aid while you travel</h3>
<div class="faq"><details><summary>Knocked-out adult tooth</summary><div class="a">Hold it by the crown, not the root. Rinse briefly in milk. Put it back in the socket if you can, or keep it in milk, and come in straight away. The first hour matters most.</div></details>
<details><summary>Broken or chipped tooth</summary><div class="a">Rinse with warm water, keep any piece in milk, use a cold compress on the cheek, and avoid chewing on that side.</div></details>
<details><summary>Severe toothache</summary><div class="a">Rinse with warm salt water, floss gently to remove trapped food, and take ordinary pain relief as directed on the pack. Don't put aspirin on the gum.</div></details>
<details><summary>Bleeding after an extraction</summary><div class="a">Bite firmly on folded gauze for 30 minutes without checking. Sit upright and avoid rinsing or hot drinks. Call if it doesn't settle.</div></details></div>
<p class="small muted" style="margin-top:16px">Open Monday–Saturday, 9:30 am – 8 pm. Call before you come. <span class="pending">Confirm Sunday</span></p></div>
</div></section>

<section class="section" id="root-canal" data-treatment="Root canal treatment" aria-labelledby="rct-h"><div class="wrap split">
<div class="photo" style="aspect-ratio:1/1"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/dr-shikha-reception.webp" alt="Dr Shikha Goel, endodontist, at the Goel Dental reception" loading="lazy" decoding="async"></div>
<div><p class="eyebrow">Root canal treatment</p><h2 id="rct-h">Save the tooth. Often in one sitting.</h2>
<p class="lead">Done by Dr Shikha Goel, MDS in Conservative Dentistry &amp; Endodontics, with an operating microscope (4–25× magnification), rotary files, an apex locator and digital X-ray in the room.</p>
<ul class="ticks"><li>Single-sitting root canals when the tooth allows</li><li>Microscope-assisted for molars, re-treatments and cracked teeth</li><li>Same-day CAD/CAM crown available, so the tooth is finished in one visit</li><li>Local anaesthetic; laughing gas for anxious patients</li></ul>
<div class="btns"><a class="btn" href="#book" data-book data-pick="Root canal" data-cta="rct">Book a root canal consultation</a><a class="btn ghost" href="<?php echo esc_url(gd_url('root-canal-treatment')); ?>">Root canal: signs, steps, fees</a></div></div>
</div></section>

<section class="section dark" id="implants" data-treatment="Dental implants" aria-labelledby="imp-h"><div class="wrap split r">
<div class="photo" style="aspect-ratio:4/5;max-height:640px"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/dr-shikha-implant.webp" alt="Dr Shikha Goel, implantologist, in the clinic" loading="lazy" decoding="async"></div>
<div><p class="eyebrow">Dental implants</p><h2 id="imp-h">Replace a missing tooth with a fixed one.</h2>
<p class="lead">Free implant consultation with a CBCT 3D scan for planning. You choose the implant system; the fee for each is published.</p>
<div class="tw" style="margin:22px 0;border-color:rgba(255,255,255,.18)"><table class="tbl" style="background:transparent;color:var(--on-night)"><thead><tr><th style="background:rgba(255,255,255,.06);color:var(--on-night-mute)">Implant system</th><th style="background:rgba(255,255,255,.06);color:var(--on-night-mute)">Per implant</th></tr></thead><tbody>
<tr><td>Adin / Alpha Bio</td><td class="n">₹17,000</td></tr><tr><td>Osstem</td><td class="n">₹35,000</td></tr><tr><td>Nobel Biocare</td><td class="n">₹40,000–45,000</td></tr><tr><td>Straumann</td><td class="n">₹55,000</td></tr><tr><td>All-on-4 (full arch)</td><td class="n">₹90,000–1,00,000</td></tr></tbody></table></div>
<p class="small">Crown on the implant is separate (₹8,500 PFM to ₹17,000 same-day CAD/CAM). Fees from the clinic's 2026 fee list. <span class="pending">Confirm before ads quote it</span></p>
<div class="btns"><a class="btn accent" href="#book" data-book data-pick="Implants" data-cta="implants">Book free implant consultation</a><a class="btn wa" href="#" data-wa data-t="Dental implants" data-cta="implants"><svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.3-.4.8-1.4a.5.5 0 0 0 0-.5l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6a2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.3-.2-.5-.3z"/></svg> Ask on WhatsApp</a></div></div>
</div></section>

<section class="section" id="fees" aria-labelledby="fee-h"><div class="wrap">
<div class="head"><div><p class="eyebrow">Fees</p><h2 id="fee-h">Prices, published before you visit.</h2><p class="lead" style="margin:12px 0 0">No surprises at the counter. These are the clinic's published fees; your exact fee comes in writing after the exam.</p></div></div>
<div class="grid g2">
<div class="tw"><table class="tbl"><thead><tr><th>Consultation &amp; general</th><th>Fee</th></tr></thead><tbody>
<tr><td>Implant / cosmetic consultation</td><td class="n">₹0</td></tr><tr><td>General consultation</td><td class="n">₹500</td></tr><tr><td>X-ray, 1–3 teeth / full mouth (OPG)</td><td class="n">₹150 / ₹500</td></tr><tr><td>CBCT scan</td><td class="n">₹2,500–4,500</td></tr><tr><td>Scaling &amp; polishing</td><td class="n">₹2,500</td></tr><tr><td>Tooth filling</td><td class="n">from ₹800</td></tr></tbody></table></div>
<div class="tw"><table class="tbl"><thead><tr><th>Root canal &amp; crowns</th><th>Fee</th></tr></thead><tbody>
<tr><td>Root canal: front / premolar / molar</td><td class="n">₹4,500 / 5,500 / 6,500</td></tr><tr><td>Single-sitting root canal</td><td class="n">₹7,500</td></tr><tr><td>Microscopic root canal</td><td class="n">₹8,500</td></tr><tr><td>Metal-ceramic crown</td><td class="n">₹6,500</td></tr><tr><td>Metal-free zirconia crown</td><td class="n">₹8,000</td></tr><tr><td>Same-day CAD/CAM crown</td><td class="n">₹12,000–14,000</td></tr></tbody></table></div>
</div>
<p class="small muted" style="margin-top:14px"><a href="<?php echo esc_url(gd_url('cost-of-dental-procedures')); ?>">Full fee list</a> · From the clinic's published 2026 price list. Final fee is confirmed in writing after the exam. EMI on leading credit cards. <span class="pending">Clinic to confirm all fees</span></p>
</div></section>

<section class="section alt" id="doctors" aria-labelledby="doc-h"><div class="wrap">
<div class="head"><div><p class="eyebrow">Clinical team</p><h2 id="doc-h">The dentists you'll meet.</h2></div><span><span class="pending">Confirm current team</span></span></div>
<div class="grid g4">
<article class="doc"><div class="photo"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/dr-shikha-portrait.webp" alt="Dr Shikha Goel" loading="lazy" decoding="async"></div><p class="role">Director · Endodontist &amp; cosmetic dentist</p><h3>Dr Shikha Goel</h3><p class="cred">MDS, Conservative Dentistry &amp; Endodontics, Bapuji Dental College (2010). Former Research Officer, AIIMS. Registered with the Delhi Dental Council.</p></article>
<article class="doc"><div class="photo"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/dr-kohli.webp" alt="Dr Sanchaita Kohli" loading="lazy" decoding="async"></div><p class="role">Oral &amp; maxillofacial surgeon</p><h3>Dr Sanchaita Kohli</h3><p class="cred">MDS. 13+ years at Maulana Azad Institute of Dental Sciences. ATLS provider; AOCMF trauma certified.</p></article>
<article class="doc"><div class="photo"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/dr-nisheet.webp" alt="Dr Nisheet Sharma" loading="lazy" decoding="async"></div><p class="role">Orthodontist</p><h3>Dr Nisheet Sharma</h3><p class="cred">MDS Orthodontics, IDST Muradnagar. Complex alignment, relapse cases, invisible and lingual braces.</p></article>
<article class="doc"><div class="photo"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/dr-akansha.webp" alt="Dr Akansha Uniyal" loading="lazy" decoding="async"></div><p class="role">In-house dentist</p><h3>Dr Akansha Uniyal</h3><p class="cred">BDS, MDS Oral Pathology, Maulana Azad Dental College, New Delhi.</p></article>
</div>
<div class="grid g2" style="margin-top:28px">
<div class="card"><p class="role eyebrow" style="margin:0">Periodontist · gum specialist</p><h3 style="margin:0">Dr Ambica Sharma</h3><p class="small muted" style="margin:0">MDS, Govt Dental College Ahmedabad (2011); 3 years Senior Resident, AIIMS. <span class="pending">Photo needed</span></p></div>
<div class="card"><p class="role eyebrow" style="margin:0">Orthodontist</p><h3 style="margin:0">Dr Parag Gupta</h3><p class="small muted" style="margin:0">Trained at I.T.S-CDSR Muradnagar; member, Indian Orthodontic Society. <span class="pending">Photo needed</span></p></div>
</div></div></section>

<section class="section" aria-labelledby="cases-h"><div class="wrap">
<div class="head"><div><p class="eyebrow">Real cases</p><h2 id="cases-h">Results from this clinic.</h2><p class="lead" style="margin:12px 0 0">Drag to compare. Cases treated at the clinic. Results vary between patients.</p></div><span><span class="pending">Confirm patient consent</span></span></div>
<div class="grid g3">
<figure style="margin:0"><div class="ba"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/ems-gbt-case-1-pre.webp" alt="Heavy deposits on teeth before cleaning" loading="lazy" decoding="async"><img class="after" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/ems-gbt-case-1-post.webp" alt="Teeth after EMS Airflow cleaning"><span class="l a">Before</span><span class="l b">After</span><input type="range" min="0" max="100" value="50" aria-label="Drag to compare before and after"><span class="hdl" aria-hidden="true"></span></div><figcaption class="cap">EMS Airflow cleaning: heavy deposits removed in one visit.</figcaption></figure>
<figure style="margin:0"><div class="ba"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/invisalign-case-3-pre.webp" alt="Wide gaps between front teeth before treatment" loading="lazy" decoding="async"><img class="after" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/invisalign-case-3-post.webp" alt="Gaps closed after Invisalign"><span class="l a">Before</span><span class="l b">After</span><input type="range" min="0" max="100" value="50" aria-label="Drag to compare before and after"><span class="hdl" aria-hidden="true"></span></div><figcaption class="cap">Invisalign: wide front-teeth gaps closed.</figcaption></figure>
<figure style="margin:0"><div class="ba"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/veneer-case-2-pre.webp" alt="Uneven front teeth before treatment" loading="lazy" decoding="async"><img class="after" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/veneer-case-2-post.webp" alt="Front teeth after E.max veneers"><span class="l a">Before</span><span class="l b">After</span><input type="range" min="0" max="100" value="50" aria-label="Drag to compare before and after"><span class="hdl" aria-hidden="true"></span></div><figcaption class="cap">E.max veneers on uneven front teeth.</figcaption></figure>
</div></div></section>

<section class="section alt" id="clinic" aria-labelledby="clinic-h"><div class="wrap">
<div class="head"><div><p class="eyebrow">Clinic tour</p><h2 id="clinic-h">Inside Goel Dental, Malviya Nagar.</h2></div></div>
<div class="mosaic">
<a class="w2 t2" href="#visit"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/operatory.webp" alt="Treatment operatories with dental chairs" loading="lazy" decoding="async"><span><b>Operatories</b><i>Separate rooms, natural light</i></span></a>
<a href="#visit"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/entrance.webp" alt="Clinic entrance corridor" loading="lazy" decoding="async"><span><b>Entrance</b></span></a>
<a href="#visit"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/waiting.webp" alt="Reception and waiting area" loading="lazy" decoding="async"><span><b>Waiting lounge</b></span></a>
<a class="w2" href="#visit"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/digital-zone.webp" alt="Digital dentistry zone with scanner and milling unit" loading="lazy" decoding="async"><span><b>Digital dentistry zone</b><i>Scan, design, mill on site</i></span></a>
<a href="#visit"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/opg.webp" alt="OPG machine" loading="lazy" decoding="async"><span><b>Imaging corner</b><i>OPG and CBCT</i></span></a>
<a href="#visit"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/steril.webp" alt="Sterilisation room" loading="lazy" decoding="async"><span><b>Sterilisation room</b></span></a>
<a class="w2" href="#visit"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/consult-room.webp" alt="Consultation room" loading="lazy" decoding="async"><span><b>Consultation room</b><i>Plans and fees explained here</i></span></a>
</div></div></section>

<section class="section" aria-labelledby="vid-h"><div class="wrap">
<div class="head"><div><p class="eyebrow">Patient videos</p><h2 id="vid-h">Hear it from patients.</h2></div></div>
<div class="grid g3"><?php echo do_shortcode('[gd_video id="BbLaB6RNURU" title="Patient video 1"][gd_video id="mLdJ6nZorm8" title="Patient video 2"][gd_video id="yzci_b4DlkQ" title="Patient video 3"]'); ?></div>
<p class="small muted" style="margin-top:14px">Videos as published on goeldentalcare.com. <span class="pending">Confirm consent for ads use</span></p>
</div></section>
<section class="section" aria-labelledby="rv-h"><div class="wrap">
<div class="head"><div><p class="eyebrow">Patient reviews</p><h2 id="rv-h">4.8 on Google, from 717 reviews.</h2></div><a class="btn ghost sm" href="https://www.google.com/maps/search/?api=1&query=Goel+Dental+14%2F185+Main+Shivalik+Road+Malviya+Nagar+New+Delhi" data-cta="reviews">Read them on Google</a></div>
<div class="grid g3">
<figure class="quote" style="margin:0"><blockquote>"I visited Dr Shikha Goel due to severe tooth pain. She explained the cause and treatment in detail. I got one wisdom tooth removed and one root canal done… I got a single-day crown also in 1 hour, which saved me a visit."</blockquote><figcaption>Rekha Uniyal · Root canal &amp; extraction</figcaption></figure>
<figure class="quote" style="margin:0"><blockquote>"I went for an RCT. Full treatment was done in a single sitting, and even the crown was delivered the same day. Dr Shikha involved me in designing my crown."</blockquote><figcaption>Sandeep Goyal · Single-sitting RCT</figcaption></figure>
<figure class="quote" style="margin:0"><blockquote>"My son is currently undergoing treatment for teeth alignment with Dr Shikha Goel… I've also had my own teeth cleaned by her, and the experience was wonderful."</blockquote><figcaption>Richa Hora · Kids' orthodontics &amp; cleaning</figcaption></figure>
</div>
<p class="small muted" style="margin-top:14px">Patient words, shortened. <a href="https://www.google.com/maps/search/?api=1&query=Goel+Dental+14%2F185+Main+Shivalik+Road+Malviya+Nagar+New+Delhi" data-cta="reviews_note">Read all 717 reviews on Google</a>. <span class="pending">Confirm source &amp; consent</span></p>
</div></section>

<section class="section alt" aria-labelledby="how-h"><div class="wrap">
<div class="head"><div><p class="eyebrow">How a visit works</p><h2 id="how-h">From first message to follow-up.</h2></div></div>
<ol class="steps"><li><h3>Tell us the problem</h3><p>Call, WhatsApp or book here. Name and mobile is enough.</p></li><li><h3>We confirm a time</h3><p>The front desk calls back and books the right specialist.</p></li><li><h3>Exam and written plan</h3><p>X-ray if needed. Options and fees in writing.</p></li><li><h3>Treatment</h3><p>Only after you agree. Local anaesthetic; sedation if needed.</p></li><li><h3>Aftercare</h3><p>Written aftercare and a review visit.</p></li></ol>
</div></section>

<section class="section" aria-labelledby="facts-h"><div class="wrap">
<div class="head"><div><p class="eyebrow">Goel Dental in brief</p><h2 id="facts-h">The facts.</h2></div></div>
<dl class="factgrid">
<div><dt>Clinic</dt><dd>Goel Dental, a dental clinic in Malviya Nagar, South Delhi, open since 2011.</dd></div>
<div><dt>Address</dt><dd>14/185, Main Shivalik Road, Malviya Nagar, New Delhi 110017, next to Sunil Hospital.</dd></div>
<div><dt>Accreditation</dt><dd>Listed by NABH as an accredited dental facility, certificate D-2020-0114. <span class="pending">Confirm current validity</span></dd></div>
<div><dt>Led by</dt><dd>Dr Shikha Goel, endodontist (MDS, Conservative Dentistry &amp; Endodontics).</dd></div>
<div><dt>Specialists</dt><dd>Endodontist, oral surgeon, two orthodontists, periodontist and an in-house dentist.</dd></div>
<div><dt>Treatments</dt><dd>Root canals, implants, crowns, extractions, cleaning, gum care, braces, aligners and children's dentistry.</dd></div>
<div><dt>Fees</dt><dd>Published: consultation ₹500; root canal from ₹4,500; implants from ₹17,000. <a href="<?php echo esc_url(gd_url('cost-of-dental-procedures')); ?>">Full fee list</a></dd></div>
<div><dt>Google rating</dt><dd>4.8 from 717 reviews (November 2026).</dd></div>
<div><dt>Hours</dt><dd>Monday–Saturday, 9:30 am–8 pm. <span class="pending">Confirm Sunday</span></dd></div>

</dl></div></section>
<section class="section" aria-labelledby="faq-h"><div class="wrap split" style="align-items:start">
<div><p class="eyebrow">Questions</p><h2 id="faq-h">Before you book.</h2><p class="lead">Still unsure? <a href="#" data-wa data-cta="faq">Ask on WhatsApp</a> or see <a href="<?php echo esc_url(gd_url('dental-faqs')); ?>">all dental questions</a>.</p></div>
<div class="faq">
<details><summary>How much does a root canal cost?</summary><div class="a">From ₹4,500 for a front tooth to ₹6,500 for a molar; ₹7,500 single-sitting; ₹8,500 microscopic. A crown is usually advised for back teeth. You get the exact fee after the exam.</div></details>
<details><summary>Is the implant consultation really free?</summary><div class="a">Yes, per the clinic's published 2026 fee list. A CBCT scan, if needed for planning, is ₹2,500–4,500.</div></details>
<details><summary>Can I be seen the same day for tooth pain?</summary><div class="a">Call first. Urgent cases are fitted in the same day whenever the schedule allows.</div></details>
<details><summary>Do you treat children?</summary><div class="a">Yes, in a separate children's room, with fluoride, sealants, kids' root canals and laughing-gas sedation for anxious children.</div></details>
<details><summary>Do you offer EMI?</summary><div class="a">Yes, on leading credit cards. Ask the front desk which cards and tenures apply.</div></details>
<details><summary>How do I get there by metro?</summary><div class="a">Malviya Nagar station (Yellow Line), Gate 1, then about 10 minutes' walk on Main Shivalik Road, next to Sunil Hospital.</div></details>
</div></div></section>

<section class="section alt" id="book" aria-labelledby="book-h"><div class="wrap split" style="align-items:start">
<div><p class="eyebrow">Book appointment</p><h2 id="book-h">Book in under a minute.</h2><p class="lead">No payment to book. The front desk confirms the time and the right dentist.</p>
<ul class="ticks"><li>Call-back within 30 minutes in clinic hours <span class="pending">Confirm SLA</span></li><li>Fee confirmed in writing before treatment</li><li>Your reference number links this request to your visit</li></ul>
<p>Prefer to talk? <a href="tel:+919310207552" data-cta="book_section">+91 93102 07552</a></p></div>
<div class="formcard">
<form class="form" id="bookform" novalidate>
<div><h3 style="margin-bottom:6px">Book an appointment</h3><p class="small muted" style="margin:0">Two details. The front desk confirms the time by phone or WhatsApp. </p></div>
<fieldset style="border:0;padding:0;margin:0" class="field"><legend class="legend" style="margin-bottom:8px">What is it for? <span class="muted" style="font-weight:400">(optional)</span></legend><div class="opts"><label class="opt"><input type="radio" name="treatment" value="Tooth pain / check-up"><span>Tooth pain / check-up</span></label><label class="opt"><input type="radio" name="treatment" value="Root canal"><span>Root canal</span></label><label class="opt"><input type="radio" name="treatment" value="Implants"><span>Implants</span></label><label class="opt"><input type="radio" name="treatment" value="Braces / aligners"><span>Braces / aligners</span></label><label class="opt"><input type="radio" name="treatment" value="Cleaning / gums"><span>Cleaning / gums</span></label><label class="opt"><input type="radio" name="treatment" value="Extraction / wisdom tooth"><span>Extraction / wisdom tooth</span></label><label class="opt"><input type="radio" name="treatment" value="Child&#x27;s check-up"><span>Child&#x27;s check-up</span></label><label class="opt"><input type="radio" name="treatment" value="Cosmetic / whitening"><span>Cosmetic / whitening</span></label></div></fieldset>
<div class="field"><label for="bf-time">Preferred time <span class="muted" style="font-weight:400">(optional)</span></label><select class="input" id="bf-time" name="time"><option value="">Any time</option><option>Today</option><option>Tomorrow morning</option><option>Tomorrow evening</option><option>This week</option><option>Weekend</option></select></div>
<div class="field"><label for="bf-name">Your name</label><input class="input" id="bf-name" name="name" autocomplete="name"><p class="err" data-e="name" hidden>Add your name so we know who to ask for.</p></div>
<div class="field"><label for="bf-phone">Mobile number</label><div class="phone-in"><span>+91</span><input class="input" id="bf-phone" name="phone" inputmode="tel" autocomplete="tel-national" placeholder="98xxxxxxxx"></div><p class="err" data-e="phone" hidden>Enter a 10-digit Indian mobile number.</p></div>
<label class="consent"><input type="checkbox" name="consent"><span>I agree to be contacted about this appointment. Details are used only to arrange care.</span></label><p class="err" data-e="consent" hidden>Please tick to let us contact you.</p>
<button class="btn" type="submit">Request appointment</button>
</form>
<div class="confirm" id="bookdone" hidden>
<p class="eyebrow" style="margin:0">Request received</p><h3 tabindex="-1">Thank you. We'll call you to confirm.</h3>
<p class="muted" style="margin:0">Reference <b class="ref" data-f="ref"></b><br>For: <b data-f="t"></b></p>
<p class="small muted" style="margin:0">During clinic hours the front desk calls back within 30 minutes <span class="pending">Confirm SLA</span>. Your details go only to the clinic front desk.</p>
<a class="btn wa" href="#" data-wa data-cta="confirmation"><svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.3-.4.8-1.4a.5.5 0 0 0 0-.5l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6a2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.3-.2-.5-.3z"/></svg> Continue on WhatsApp</a>
</div></div>
</div></section>

<section class="section" id="visit" aria-labelledby="visit-h"><div class="wrap split">
<div><p class="eyebrow">Visit us</p><h2 id="visit-h">On Main Shivalik Road, Malviya Nagar.</h2>
<p class="lead" style="margin-bottom:10px">Goel Dental<br>14/185, Ground Floor <span class="pending">Ground vs Lower Ground</span><br>Main Shivalik Road, Malviya Nagar<br>New Delhi 110017</p>
<p class="muted">Next to Sunil Hospital, near the Liberty showroom. 10 minutes from Malviya Nagar metro, Gate 1. Patients come from Shivalik, Saket, Sheikh Sarai, Chhattarpur, Munirka, Vasant Kunj and Hauz Khas.</p>
<p><b>Mon–Sat, 9:30 am – 8:00 pm</b> <span class="pending">Confirm hours &amp; Sunday</span></p>
<div class="btns"><a class="btn" href="https://www.google.com/maps/search/?api=1&query=Goel+Dental+14%2F185+Main+Shivalik+Road+Malviya+Nagar+New+Delhi" rel="noopener" data-cta="visit">Get directions</a><a class="btn ghost" href="tel:+919310207552" data-cta="visit"><svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3h3l2 5-2.5 1.5a11 11 0 0 0 7 7L16 14l5 2v3a2 2 0 0 1-2 2A17 17 0 0 1 3 5a2 2 0 0 1 2-2z"/></svg> Call</a></div></div>
<div class="photo" style="aspect-ratio:4/3"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/happy-patient.webp" alt="Patient and dentist at Goel Dental" loading="lazy" decoding="async"></div>
</div></section>
</main>
<?php get_footer(); ?>
