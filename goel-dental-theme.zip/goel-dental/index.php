<?php get_header(); ?>
<main id="main">
<section class="page-hero"><div class="wrap">
<p class="crumbs"><a href="<?php echo esc_url(home_url('/')); ?>">Home</a> / Articles</p>
<p class="eyebrow">Goel Dental · Malviya Nagar</p>
<h1><?php echo is_home() ? 'Articles from Goel Dental' : esc_html(wp_strip_all_tags(get_the_archive_title())); ?></h1>
</div></section>
<section class="section"><div class="wrap"><div class="grid g2">
<?php if (have_posts()) : while (have_posts()) : the_post(); $d = get_post_meta(get_the_ID(), '_yoast_wpseo_metadesc', true); ?>
<a class="tcard" href="<?php the_permalink(); ?>"><b><?php the_title(); ?></b><span><?php echo esc_html($d ?: wp_trim_words(get_the_excerpt(), 28)); ?></span><em><?php echo esc_html(get_the_date('F Y')); ?></em><i aria-hidden="true">→</i></a>
<?php endwhile; else : ?><p>No articles yet.</p><?php endif; ?>
</div><?php the_posts_pagination(); ?></div></section>
</main>
<?php get_footer(); ?>
