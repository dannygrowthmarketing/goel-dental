<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(gd_show_flags() ? '' : 'gd-hide-flags'); ?>>
<?php wp_body_open(); ?>
<a class="skip" href="#main">Skip to content</a>
<header class="hd"><div class="wrap">
<a class="logo" href="<?php echo esc_url(home_url('/')); ?>"><img class="mark" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/gd-mark.webp" alt="" width="38" height="37">Goel Dental <small>Malviya Nagar</small></a>
<nav class="nav" aria-label="Main"><a href="<?php echo esc_url(home_url('/')); ?>#treatments">Treatments</a><a href="<?php echo esc_url(home_url('/')); ?>#emergency">Emergency</a><a href="<?php echo esc_url(home_url('/')); ?>#fees">Fees</a><a href="<?php echo esc_url(home_url('/')); ?>#doctors">Doctors</a><a href="<?php echo esc_url(home_url('/')); ?>#clinic">Clinic</a><a href="<?php echo esc_url(home_url('/')); ?>#visit">Visit</a><a href="tel:+919310207552" data-cta="header">+91 93102 07552</a></nav>
<a class="btn sm accent hd-cta" href="<?php echo esc_url(home_url('/')); ?>#book" data-book data-cta="header">Book</a>
<button class="burger" type="button" aria-expanded="false" aria-controls="drawer" aria-label="Menu"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 7h18M3 12h18M3 17h18"/></svg></button>
</div><nav class="drawer" id="drawer" aria-label="Mobile"><a href="<?php echo esc_url(home_url('/')); ?>#treatments">Treatments</a><a href="<?php echo esc_url(home_url('/')); ?>#emergency">Emergency</a><a href="<?php echo esc_url(home_url('/')); ?>#fees">Fees</a><a href="<?php echo esc_url(home_url('/')); ?>#doctors">Doctors</a><a href="<?php echo esc_url(home_url('/')); ?>#clinic">Clinic tour</a><a href="<?php echo esc_url(home_url('/')); ?>#visit">Visit us</a><a href="<?php echo esc_url(home_url('/')); ?>#book">Book appointment</a></nav></header>
