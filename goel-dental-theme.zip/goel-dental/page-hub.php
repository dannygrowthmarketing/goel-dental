<?php /* Template Name: Treatments hub */ get_header(); while (have_posts()) : the_post(); ?>
<main id="main">
<section class="page-hero"><div class="wrap"><?php gd_breadcrumbs(); ?><p class="eyebrow">Treatments · Goel Dental, Malviya Nagar</p><h1><?php the_title(); ?></h1>
<p class="lead" style="color:var(--on-night-mute)"><?php echo esc_html(get_post_meta(get_the_ID(), 'gd_quick', true)); ?></p></div></section>
<?php foreach (gd_groups() as $g => $slugs) : ?>
<section class="section<?php echo ($i = ($i ?? 0) + 1) % 2 ? '' : ' alt'; ?>"><div class="wrap"><div class="head"><div><p class="eyebrow"><?php echo esc_html($g); ?></p></div></div>
<div class="grid g3"><?php foreach ($slugs as $s) gd_card($s); ?></div></div></section>
<?php endforeach; ?>
<section class="section"><div class="wrap entry"><?php the_content(); ?></div></section>
</main>
<?php endwhile; get_footer();
