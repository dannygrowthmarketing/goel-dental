<?php /* Template Name: Book appointment */ get_header(); while (have_posts()) : the_post(); ?>
<main id="main">
<section class="page-hero"><div class="wrap"><?php gd_breadcrumbs(); ?><p class="eyebrow">Book appointment</p><h1><?php the_title(); ?></h1></div></section>
<section class="section" id="book"><div class="wrap split" style="align-items:start"><div class="entry"><?php the_content(); ?></div>
<?php get_template_part('parts/book-form'); ?></div></section>
</main>
<?php endwhile; get_footer();
