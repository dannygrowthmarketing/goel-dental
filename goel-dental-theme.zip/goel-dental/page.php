<?php get_header(); while (have_posts()) : the_post();
$id = get_the_ID(); $m = fn($k) => get_post_meta($id, $k, true);
$eyebrow = $m('gd_eyebrow') ?: 'Goel Dental · Malviya Nagar';
$quick = $m('gd_quick'); $fee = $m('gd_fee'); $visits = $m('gd_visits'); $who = $m('gd_who');
$t = esc_attr(get_the_title()); ?>
<main id="main">
<section class="page-hero"><div class="wrap">
<?php gd_breadcrumbs(); ?>
<p class="eyebrow"><?php echo esc_html($eyebrow); ?></p>
<h1><?php the_title(); ?></h1>
<?php if ($quick) : ?><div class="quick" role="note"><p class="quick-l">Quick answer</p><p><?php echo wp_kses_post($quick); ?></p>
<?php if ($fee || $visits || $who) : ?><dl class="facts"><?php if ($fee) : ?><div><dt>Fee</dt><dd><?php echo esc_html($fee); ?></dd></div><?php endif; if ($visits) : ?><div><dt>Visits</dt><dd><?php echo esc_html($visits); ?></dd></div><?php endif; if ($who) : ?><div><dt>Done by</dt><dd><?php echo esc_html($who); ?></dd></div><?php endif; ?></dl><?php endif; ?></div><?php endif; ?>
<div class="btns"><a class="btn accent" href="<?php echo esc_url(gd_url('make-an-appointment')); ?>" data-book data-cta="page_hero" data-t="<?php echo $t; ?>">Book appointment</a><a class="btn ghost" style="color:var(--on-night);border-color:rgba(255,255,255,.45)" href="tel:<?php echo esc_attr(GD_TEL); ?>" data-cta="page_hero" data-t="<?php echo $t; ?>">Call <?php echo esc_html(GD_PHONE); ?></a><a class="btn wa" href="#" data-wa data-cta="page_hero" data-t="<?php echo $t; ?>">WhatsApp</a></div>
</div></section>
<section class="section"><div class="wrap layout">
<article class="entry" data-treatment="<?php echo $t; ?>"><?php the_content(); ?></article>
<aside><div class="card aside-cta"><p class="eyebrow" style="margin:0">Next step</p><h3 style="margin:0">Talk to the clinic</h3><p class="small muted" style="margin:0">4.8★ from 708 Google reviews. Fee confirmed in writing before treatment.</p>
<a class="btn" href="<?php echo esc_url(gd_url('make-an-appointment')); ?>" data-book data-cta="page_aside" data-t="<?php echo $t; ?>">Book appointment</a>
<a class="btn wa" href="#" data-wa data-cta="page_aside" data-t="<?php echo $t; ?>">WhatsApp</a>
<a class="btn ghost" href="tel:<?php echo esc_attr(GD_TEL); ?>" data-cta="page_aside" data-t="<?php echo $t; ?>">Call <?php echo esc_html(GD_PHONE); ?></a></div></aside>
</div></section>
<?php gd_related(); ?>
</main>
<?php endwhile; get_footer();
