<?php get_header(); while (have_posts()) : the_post(); ?>
<main id="main">
<section class="page-hero"><div class="wrap">
<p class="crumbs"><a href="<?php echo esc_url(home_url('/')); ?>">Home</a> / <?php the_title(); ?></p>
<p class="eyebrow">Goel Dental · Malviya Nagar</p>
<h1><?php the_title(); ?></h1>
<div class="btns"><a class="btn accent" href="<?php echo esc_url(home_url('/#book')); ?>" data-book data-cta="page_hero" data-t="<?php echo esc_attr(get_the_title()); ?>">Book appointment</a><a class="btn ghost" style="color:var(--on-night);border-color:rgba(255,255,255,.45)" href="tel:<?php echo esc_attr(GD_TEL); ?>" data-cta="page_hero" data-t="<?php echo esc_attr(get_the_title()); ?>">Call <?php echo esc_html(GD_PHONE); ?></a><a class="btn wa" href="#" data-wa data-cta="page_hero" data-t="<?php echo esc_attr(get_the_title()); ?>">WhatsApp</a></div>
</div></section>
<section class="section"><div class="wrap layout">
<article class="entry" data-treatment="<?php echo esc_attr(get_the_title()); ?>"><?php the_content(); ?></article>
<aside><div class="card aside-cta"><p class="eyebrow" style="margin:0">Next step</p><h3 style="margin:0">Talk to the clinic</h3><p class="small muted" style="margin:0">4.8★ from 708 Google reviews. Fee confirmed in writing before treatment.</p>
<a class="btn" href="<?php echo esc_url(home_url('/#book')); ?>" data-book data-cta="page_aside" data-t="<?php echo esc_attr(get_the_title()); ?>">Book appointment</a>
<a class="btn wa" href="#" data-wa data-cta="page_aside" data-t="<?php echo esc_attr(get_the_title()); ?>">WhatsApp</a>
<a class="btn ghost" href="tel:<?php echo esc_attr(GD_TEL); ?>" data-cta="page_aside" data-t="<?php echo esc_attr(get_the_title()); ?>">Call <?php echo esc_html(GD_PHONE); ?></a></div></aside>
</div></section>
</main>
<?php endwhile; get_footer(); ?>
