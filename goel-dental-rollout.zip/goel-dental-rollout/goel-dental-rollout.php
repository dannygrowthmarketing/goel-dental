<?php
/*
Plugin Name: Goel Dental Rollout
Description: Serves the new Goel Dental theme on the homepage and rebuilt pages only; every other URL keeps the current theme. New page copy is stored in page meta (gd_content), so the original content is untouched. Deactivate this plugin to roll back instantly.
Version: 1.0.0
Author: Daniel Deepak
*/
if (!defined('ABSPATH')) exit;
const GDR_THEME = 'goel-dental';
function gdr_slugs() { return ['dental-treatments','root-canal-treatment','single-sitting-root-canal-treatment','microscopic-root-canal-treatment','dental-emergency','dental-implants','full-mouth-dental-implants','dental-bridge-tooth-crown','wisdom-teeth-extraction','non-surgical-tooth-extraction','scaling-and-polishing','ems-gbt-teeth-cleaning','gum-disease-treatment','orthodontics','invisible-braces','tooth-colored-filling','kids-dentistry','cost-of-dental-procedures','our-dentists','dentist-in-kalkaji','dentist-near-saket','contact-form','make-an-appointment']; }
function gdr_is_switched_request() {
  static $r = null; if ($r !== null) return $r;
  if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST) || wp_doing_cron()) return $r = false;
  if (get_option('gdr_enabled', '1') !== '1' && !current_user_can('edit_pages')) return $r = false;
  if (!empty($_GET['gdr_preview']) && $_GET['gdr_preview'] === 'old') return $r = false;
  $path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
  if ($path === '' || $path === 'index.php') return $r = true;
  $slug = preg_replace('/\.html$/', '', $path);
  return $r = in_array($slug, gdr_slugs(), true);
}
add_filter('pre_option_template', fn($v) => (gdr_is_switched_request() && wp_get_theme(GDR_THEME)->exists()) ? GDR_THEME : $v);
add_filter('pre_option_stylesheet', fn($v) => (gdr_is_switched_request() && wp_get_theme(GDR_THEME)->exists()) ? GDR_THEME : $v);

/* New copy lives in gd_content; original post_content stays as it was. */
add_filter('the_content', function ($c) {
  if (!gdr_is_switched_request() || !in_the_loop()) return $c;
  $n = get_post_meta(get_the_ID(), 'gd_content', true);
  return $n !== '' ? $n : $c;
}, 1);
/* Page template stored per page for the new theme only */
add_filter('template_include', function ($t) {
  if (!gdr_is_switched_request() || !is_page()) return $t;
  $tpl = get_post_meta(get_queried_object_id(), 'gd_template', true);
  if ($tpl && ($f = locate_template($tpl))) return $f;
  return $t;
}, 99);

/* Meta used by the new theme, editable over REST by editors */
add_action('init', function () {
  foreach (['gd_content','gd_template','gd_eyebrow','gd_short','gd_card','gd_fee','gd_visits','gd_who','gd_quick','gd_parent','gd_related','gd_schema','gd_people','gd_branch','gd_old_yoast','_yoast_wpseo_title','_yoast_wpseo_metadesc'] as $k)
    register_post_meta('page', $k, ['type' => 'string', 'single' => true, 'show_in_rest' => true, 'auth_callback' => fn() => current_user_can('edit_pages')]);
  register_post_type('gd_lead', ['label' => 'Leads', 'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-groups', 'supports' => ['title'], 'map_meta_cap' => true]);
});

/* Leads (moved here so they work whatever theme admin-ajax runs under) */
function gdr_lead_save() {
  if (!wp_verify_nonce($_POST['_gd'] ?? '', 'gd_lead')) wp_send_json_error('bad nonce', 403);
  $name  = sanitize_text_field($_POST['name'] ?? '');
  $phone = preg_replace('/\D/', '', $_POST['phone'] ?? ''); $phone = preg_replace('/^(91|0)(?=\d{10}$)/', '', $phone);
  if (!$name || !preg_match('/^[6-9]\d{9}$/', $phone) || empty($_POST['consent'])) wp_send_json_error('invalid', 400);
  $lid = sanitize_text_field($_POST['lead_id'] ?? '');
  $id = wp_insert_post(['post_type' => 'gd_lead', 'post_status' => 'private', 'post_title' => $lid . ' · ' . $name]);
  update_post_meta($id, 'name', $name); update_post_meta($id, 'phone', $phone); update_post_meta($id, 'lead_id', $lid); update_post_meta($id, 'status', 'new');
  foreach (['treatment','time','page','ref_code','ft_channel','ft_campaign','ft_landing','lt_channel','lt_source','lt_medium','lt_campaign','lt_term','gclid','fbclid'] as $k) update_post_meta($id, $k, sanitize_text_field($_POST[$k] ?? ''));
  $to = get_option('gd_lead_email', get_option('admin_email'));
  wp_mail($to, 'New appointment request ' . $lid, "Name: $name\nMobile: +91 $phone\nFor: " . sanitize_text_field($_POST['treatment'] ?? '') . "\nPreferred time: " . sanitize_text_field($_POST['time'] ?? '') . "\nSource: " . sanitize_text_field($_POST['lt_channel'] ?? '') . ' / ' . sanitize_text_field($_POST['lt_campaign'] ?? '') . "\nPage: " . sanitize_text_field($_POST['page'] ?? ''));
  wp_send_json_success(['id' => $id]);
}
add_action('wp_ajax_gd_lead', 'gdr_lead_save'); add_action('wp_ajax_nopriv_gd_lead', 'gdr_lead_save');
add_filter('manage_gd_lead_posts_columns', fn($c) => ['cb' => $c['cb'], 'title' => 'Lead', 'phone' => 'Mobile', 'treatment' => 'Treatment', 'source' => 'Source', 'status' => 'Status', 'date' => 'Received']);
add_action('manage_gd_lead_posts_custom_column', function ($col, $id) {
  if ($col === 'phone') echo esc_html('+91 ' . get_post_meta($id, 'phone', true));
  if ($col === 'treatment') echo esc_html(get_post_meta($id, 'treatment', true));
  if ($col === 'source') echo esc_html(trim(get_post_meta($id, 'lt_channel', true) . ' ' . get_post_meta($id, 'lt_campaign', true)));
  if ($col === 'status') echo esc_html(get_post_meta($id, 'status', true));
}, 10, 2);

/* Keep measurement on new pages: Google Ads tag, and send site events (call, WhatsApp, booking) to GA4 through gtag until GTM is set up. */
add_action('wp_footer', function () {
  if (!gdr_is_switched_request()) return;
  echo "<script>(function(){function g(){window.dataLayer=window.dataLayer||[];if(typeof gtag!=='function'){window.gtag=function(){dataLayer.push(arguments)}}}g();try{gtag('config','AW-971270974')}catch(e){}if(window.GD&&GD.on){GD.on(function(o){if(!o.event||o.event==='gd_context')return;var p={};for(var k in o){if(k!=='event'&&k!=='attribution'&&typeof o[k]!=='object')p[k]=o[k]}try{gtag('event',o.event,p)}catch(e){}})}})();</script>\n";
}, 99);
