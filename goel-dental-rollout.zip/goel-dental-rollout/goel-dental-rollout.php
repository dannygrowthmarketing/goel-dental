<?php
/*
Plugin Name: Goel Dental Rollout
Description: Serves the new Goel Dental theme on the homepage and rebuilt pages only; every other URL keeps the current theme. New page copy is stored in page meta (gd_content), so the original content is untouched. Deactivate this plugin to roll back instantly.
Version: 1.4.0
Author: Daniel Deepak
*/
if (!defined('ABSPATH')) exit;
const GDR_THEME = 'goel-dental';
function gdr_slugs() { return ['dental-treatments','root-canal-treatment','single-sitting-root-canal-treatment','microscopic-root-canal-treatment','dental-emergency','dental-implants','full-mouth-dental-implants','dental-bridge-tooth-crown','wisdom-teeth-extraction','non-surgical-tooth-extraction','scaling-and-polishing','ems-gbt-teeth-cleaning','gum-disease-treatment','orthodontics','invisible-braces','tooth-colored-filling','kids-dentistry','cost-of-dental-procedures','our-dentists','dentist-in-kalkaji','dentist-near-saket','contact-form','make-an-appointment','dental-faqs','about-us','endodontist-root-canal-specialist','dr-sanchaita-kohli','dr-nisheet-sharma','orthodontist-braces-specialist','periodontist-gum-specialist','dr-akansha-uniyal-2','infection-control-policy','patients-charter','dental-technology','our-cases','tele-consultation','offers-on-dental-treatment-in-delhi','metallic-braces','ceramic-braces','lingual-braces','kids-orthodontics','kids-root-canal-treatment','kids-tooth-fillings','kids-flouride-application','conscious-sedation-dental-nitrous-oxide','bone-grafting-and-sinus-lift','post-and-core','dental-crown-lengthening','chipped-tooth-repair']; }
function gdr_is_switched_request() {
  static $r = null; if ($r !== null) return $r;
  if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST) || wp_doing_cron()) return $r = false;
  if (get_option('gdr_enabled', '0') !== '1' && !current_user_can('edit_pages')) return $r = false;
  if (!empty($_GET['gdr_preview']) && $_GET['gdr_preview'] === 'old') return $r = false;
  $path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
  if ($path === '' || $path === 'index.php') return $r = true;
  $slug = preg_replace('/\.html$/', '', $path);
  return $r = in_array($slug, gdr_slugs(), true);
}
add_filter('pre_option_template', fn($v) => (gdr_is_switched_request() && wp_get_theme(GDR_THEME)->exists()) ? GDR_THEME : $v);
add_filter('pre_option_stylesheet', fn($v) => (gdr_is_switched_request() && wp_get_theme(GDR_THEME)->exists()) ? GDR_THEME : $v);

/* New copy lives in gd_content; original post_content stays as it was. */
add_filter('the_content', function ($c) {
  if (!gdr_is_switched_request() || !in_the_loop()) return $c;
  $n = get_post_meta(get_the_ID(), 'gd_content', true);
  return $n !== '' ? $n : $c;
}, 1);
/* Page template stored per page for the new theme only */
add_filter('template_include', function ($t) {
  if (!gdr_is_switched_request() || !is_page()) return $t;
  $tpl = get_post_meta(get_queried_object_id(), 'gd_template', true);
  if ($tpl && ($f = locate_template($tpl))) return $f;
  return $t;
}, 99);

/* Meta used by the new theme, editable over REST by editors */
add_action('init', function () {
  foreach (['gd_content','gd_template','gd_eyebrow','gd_short','gd_card','gd_fee','gd_visits','gd_who','gd_quick','gd_parent','gd_related','gd_schema','gd_people','gd_branch','gd_old_yoast','_yoast_wpseo_title','_yoast_wpseo_metadesc'] as $k)
    register_post_meta('page', $k, ['type' => 'string', 'single' => true, 'show_in_rest' => true, 'auth_callback' => fn() => current_user_can('edit_pages')]);
  register_post_type('gd_lead', ['label' => 'Leads', 'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-groups', 'supports' => ['title'], 'map_meta_cap' => true]);
});

/* Leads (moved here so they work whatever theme admin-ajax runs under) */
function gdr_lead_save() {
  if (!wp_verify_nonce($_POST['_gd'] ?? '', 'gd_lead')) wp_send_json_error('bad nonce', 403);
  $name  = sanitize_text_field($_POST['name'] ?? '');
  $phone = preg_replace('/\D/', '', $_POST['phone'] ?? ''); $phone = preg_replace('/^(91|0)(?=\d{10}$)/', '', $phone);
  if (!$name || !preg_match('/^[6-9]\d{9}$/', $phone) || empty($_POST['consent'])) wp_send_json_error('invalid', 400);
  $lid = sanitize_text_field($_POST['lead_id'] ?? '');
  $id = wp_insert_post(['post_type' => 'gd_lead', 'post_status' => 'private', 'post_title' => $lid . ' · ' . $name]);
  update_post_meta($id, 'name', $name); update_post_meta($id, 'phone', $phone); update_post_meta($id, 'lead_id', $lid); update_post_meta($id, 'status', 'new');
  foreach (['treatment','time','page','ref_code','ft_channel','ft_campaign','ft_landing','lt_channel','lt_source','lt_medium','lt_campaign','lt_term','gclid','fbclid'] as $k) update_post_meta($id, $k, sanitize_text_field($_POST[$k] ?? ''));
  $to = get_option('gd_lead_email', get_option('admin_email'));
  wp_mail($to, 'New appointment request ' . $lid, "Name: $name\nMobile: +91 $phone\nFor: " . sanitize_text_field($_POST['treatment'] ?? '') . "\nPreferred time: " . sanitize_text_field($_POST['time'] ?? '') . "\nSource: " . sanitize_text_field($_POST['lt_channel'] ?? '') . ' / ' . sanitize_text_field($_POST['lt_campaign'] ?? '') . "\nPage: " . sanitize_text_field($_POST['page'] ?? ''));
  wp_send_json_success(['id' => $id]);
}
add_action('wp_ajax_gd_lead', 'gdr_lead_save'); add_action('wp_ajax_nopriv_gd_lead', 'gdr_lead_save');
add_filter('manage_gd_lead_posts_columns', fn($c) => ['cb' => $c['cb'], 'title' => 'Lead', 'phone' => 'Mobile', 'treatment' => 'Treatment', 'source' => 'Source', 'status' => 'Status', 'date' => 'Received']);
add_action('manage_gd_lead_posts_custom_column', function ($col, $id) {
  if ($col === 'phone') echo esc_html('+91 ' . get_post_meta($id, 'phone', true));
  if ($col === 'treatment') echo esc_html(get_post_meta($id, 'treatment', true));
  if ($col === 'source') echo esc_html(trim(get_post_meta($id, 'lt_channel', true) . ' ' . get_post_meta($id, 'lt_campaign', true)));
  if ($col === 'status') echo esc_html(get_post_meta($id, 'status', true));
}, 10, 2);

/* Keep measurement on new pages: Google Ads tag, and send site events (call, WhatsApp, booking) to GA4 through gtag until GTM is set up. */
add_action('wp_head', function () {
  if (!gdr_is_switched_request()) return;
  echo "<script async src='https://www.googletagmanager.com/gtag/js?id=G-F2H0LCT0HC'></script>\n";
}, 2);
add_action('wp_footer', function () {
  if (!gdr_is_switched_request()) return;
  echo "<script>(function(){function g(){window.dataLayer=window.dataLayer||[];if(typeof gtag!=='function'){window.gtag=function(){dataLayer.push(arguments)}}}g();try{gtag('js',new Date());gtag('config','G-F2H0LCT0HC');gtag('config','AW-971270974')}catch(e){}if(window.GD&&GD.on){GD.on(function(o){if(!o.event||o.event==='gd_context')return;var p={};for(var k in o){if(k!=='event'&&k!=='attribution'&&typeof o[k]!=='object')p[k]=o[k]}try{gtag('event',o.event,p)}catch(e){}})}})();</script>\n";
}, 99);

/* Settings > General: switch the new pages on for everyone. Off = only logged-in editors see them. */
add_action('admin_init', function () {
  register_setting('general', 'gdr_enabled', ['sanitize_callback' => fn($v) => $v === '1' ? '1' : '0']);
  add_settings_field('gdr_enabled', 'New Goel Dental pages', function () {
    echo '<label><input type="checkbox" name="gdr_enabled" value="1" ' . checked(get_option('gdr_enabled', '0'), '1', false) . '> Live for all visitors (unticked: only logged-in editors see them)</label>';
  }, 'general');
});

/* On new pages, load only what they use: theme CSS/JS, fonts, Google tag (Site Kit), Crisp chat, admin bar for editors. */
function gdr_trim_assets() {
  if (!gdr_is_switched_request()) return;
  $keep = '/^(gd-|google_gtagjs|admin-bar|dashicons|hoverintent|wp-mail-smtp-admin-bar|yoast-seo-adminbar)/';
  foreach ([wp_scripts(), wp_styles()] as $reg) foreach ((array) $reg->queue as $h) if (!preg_match($keep, $h)) { $reg->dequeue($h); }
}
add_action('wp_enqueue_scripts', 'gdr_trim_assets', 9999);
add_action('wp_print_scripts', 'gdr_trim_assets', 1);
add_action('wp_print_footer_scripts', 'gdr_trim_assets', 1);
add_action('wp_print_styles', 'gdr_trim_assets', 1);

/* /llms.txt: a plain-text summary of the clinic for AI assistants and answer engines (llmstxt.org format). */
add_action('init', function () {
  $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
  if ($path !== '/llms.txt') return;
  $home = home_url('/');
  $lines = ["# Goel Dental, Malviya Nagar, New Delhi", "",
    "> Dental clinic at 14/185 Main Shivalik Road, Malviya Nagar, New Delhi 110017, next to Sunil Hospital. Open since 2011. Led by Dr Shikha Goel, endodontist (MDS). Listed by NABH as an accredited dental facility (certificate D-2020-0114). Fees are published on the website. Second clinic: dental department at Irene Hospital, Kalkaji.", "",
    "- Phone: +91 93102 07552", "- Email: info@goeldentalcare.com", "- Hours (Malviya Nagar): Monday to Saturday, 9:30 am to 8 pm", "- Google rating: 4.8 from 708 reviews (November 2026)", "",
    "## Treatments"];
  $groups = ['Treatments' => ['root-canal-treatment','single-sitting-root-canal-treatment','microscopic-root-canal-treatment','dental-emergency','dental-implants','full-mouth-dental-implants','dental-bridge-tooth-crown','wisdom-teeth-extraction','non-surgical-tooth-extraction','scaling-and-polishing','ems-gbt-teeth-cleaning','gum-disease-treatment','orthodontics','invisible-braces','tooth-colored-filling','kids-dentistry'],
             'Fees, questions and visiting' => ['cost-of-dental-procedures','dental-faqs','our-dentists','contact-form','make-an-appointment','dentist-in-kalkaji','dentist-near-saket']];
  $first = true;
  foreach ($groups as $g => $slugs) {
    if (!$first) { $lines[] = ''; $lines[] = '## ' . $g; } $first = false;
    foreach ($slugs as $sl) { $pg = get_page_by_path($sl); if (!$pg || $pg->post_status !== 'publish') continue;
      $d = get_post_meta($pg->ID, 'gd_quick', true) ?: get_post_meta($pg->ID, '_yoast_wpseo_metadesc', true);
      $lines[] = '- [' . get_the_title($pg) . '](' . get_permalink($pg) . '): ' . wp_strip_all_tags($d); }
  }
  $lines[] = ''; $lines[] = '## Optional'; $lines[] = '- [Homepage](' . $home . ')';
  status_header(200); header('Content-Type: text/plain; charset=utf-8'); header('Cache-Control: public, max-age=3600');
  echo implode("\n", $lines) . "\n"; exit;
}, 0);

/* Crisp chat on new pages: load on first tap, scroll or key press (or after 8 s) instead of at page load. Chat stays available. */
add_action('wp_footer', function () {
  if (!gdr_is_switched_request()) return;
  echo "<script>(function(){var done=false;function go(){if(done)return;done=true;window.\$crisp=window.\$crisp||[];window.CRISP_WEBSITE_ID='073e0c59-235c-4a03-9b09-a280947d0859';var s=document.createElement('script');s.src='https://client.crisp.chat/l.js';s.async=true;document.head.appendChild(s);}['scroll','pointerdown','keydown','touchstart'].forEach(function(e){addEventListener(e,go,{once:true,passive:true})});setTimeout(go,8000);})();</script>\n";
}, 100);

/* Old duplicate/junk pages: permanent redirects to the right page (list agreed in the 18 Nov redirect map, "Safe" rows only). */
add_action('template_redirect', function () {
  $map = ['home-new' => '/', 'about-us-3' => '/offers-on-dental-treatment-in-delhi.html', 'subscription' => '/', 'get-location' => '/contact-form.html', 'charges' => '/cost-of-dental-procedures.html', 'covid-19-best-practices-at-goel-dental' => '/infection-control-policy.html'];
  $slug = preg_replace('/\.html$/', '', trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/'));
  if (isset($map[$slug])) { wp_safe_redirect(home_url($map[$slug]), 301, 'Goel Dental Rollout'); exit; }
}, 1);

/* Thank-you pages: keep out of Google */
add_filter('wp_robots', function ($r) {
  if (is_page(['thank-you', 'thank-you-appointment', 'thank-you-payment'])) { $r['noindex'] = true; $r['follow'] = true; }
  return $r;
});
add_filter('wpseo_robots', function ($v) { return is_page(['thank-you', 'thank-you-appointment', 'thank-you-payment']) ? 'noindex, follow' : $v; });

/* Avada prints a jQuery login-nonce helper in the footer even on pages that no longer load jQuery. Strip it from new pages (logged-out visitors only). */
add_action('template_redirect', function () {
  if (!gdr_is_switched_request() || is_user_logged_in()) return;
  ob_start(function ($html) {
    return preg_replace('#<script[^>]*>\s*jQuery\(\s*document\s*\)\.ready\(\s*function\(\)\s*\{\s*var ajaxurl.{0,400}?fusion_login_nonce.{0,400}?</script>#s', '', $html);
  });
}, 2);
